## How to run

```bash
npm install
npm start
```
To stop the application, "ctrl + C" and "Y" Enter